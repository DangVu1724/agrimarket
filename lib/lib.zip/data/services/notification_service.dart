import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class NotificationService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // Send notification to seller when new order is created
  Future<void> sendOrderNotification({
    required String storeId,
    required String orderId,
    required String buyerName,
    required double totalAmount,
  }) async {
    try {
      await _firestore.collection('notifications').add({
        'storeId': storeId,
        'orderId': orderId,
        'type': 'new_order',
        'title': 'Đơn hàng mới',
        'message': 'Bạn có đơn hàng mới từ $buyerName với giá trị ${totalAmount.toStringAsFixed(0)}₫',
        'isRead': false,
        'createdAt': FieldValue.serverTimestamp(),
        'buyerName': buyerName,
        'totalAmount': totalAmount,
      });
    } catch (e) {
      print('Error sending notification: $e');
    }
  }

  // Mark notification as read
  Future<void> markNotificationAsRead(String notificationId) async {
    try {
      await _firestore.collection('notifications').doc(notificationId).update({'isRead': true});
    } catch (e) {
      print('Error marking notification as read: $e');
    }
  }

  // Get unread notifications count for a store
  Stream<int> getUnreadNotificationsCount(String storeId) {
    return _firestore
        .collection('notifications')
        .where('storeId', isEqualTo: storeId)
        .where('isRead', isEqualTo: false)
        .snapshots()
        .map((snapshot) => snapshot.docs.length);
  }

  // Listen to notifications for a store
  Stream<QuerySnapshot> listenToNotifications(String storeId) {
    return _firestore
        .collection('notifications')
        .where('storeId', isEqualTo: storeId)
        .orderBy('createdAt', descending: true)
        .limit(50)
        .snapshots();
  }
}
