import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static const FirebaseOptions currentPlatform = FirebaseOptions(
    apiKey: 'AIzaSyAF9LKr9OJxKgbEyV_KupR68NzyDOxD10k',
    appId: '1:739235439031:android:3e8316dfd6c2c3d7c5c832',
    messagingSenderId: '739235439031',
    projectId: 'agrimarket-60402',
    storageBucket: 'agrimarket-60402.firebasestorage.app',
  );
}
