import 'package:get/get.dart';

class ProfileScreenVm extends GetxController{
  // Define any variables or methods needed for the profile screen
  final RxString userName = ''.obs;
  final RxString userEmail = ''.obs;

  @override
  void onInit() {
    super.onInit();

  }

  
}