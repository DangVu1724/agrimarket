import 'package:agrimarket/app/theme/app_colors.dart';
import 'package:agrimarket/data/models/order.dart';
import 'package:agrimarket/data/services/order_service.dart';
import 'package:agrimarket/data/services/seller_store_service.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';

class SellerOrdersVm extends GetxController {
  final OrderService _orderService = OrderService();
  final SellerStoreService _sellerStoreService = SellerStoreService();
  final FirebaseAuth _auth = FirebaseAuth.instance;

  final RxList<OrderModel> orders = <OrderModel>[].obs;
  final RxBool isLoading = false.obs;
  final RxString errorMessage = ''.obs;
  final RxInt pendingOrdersCount = 0.obs;
  final RxInt totalOrdersCount = 0.obs;

  @override
  void onInit() {
    super.onInit();
    _clearData();
    _setupRealTimeListeners();
  }

  void _clearData() {
    orders.clear();
    errorMessage.value = '';
    pendingOrdersCount.value = 0;
    totalOrdersCount.value = 0;
  }

  void _setupRealTimeListeners() async {
    try {
      final storeId = await _getCurrentStoreId();
      if (storeId == null) {
        errorMessage.value = 'Không tìm thấy cửa hàng của bạn';
        return;
      }
      // Listen to orders in real-time
      _orderService.listenToOrdersByStoreId(
        storeId: storeId,
        onOrdersChanged: (List<OrderModel> newOrders) {
          orders.assignAll(newOrders);
          _updateOrderCounts();
        },
        onError: (error) {
          errorMessage.value = 'Lỗi kết nối: $error';
        },
      );
    } catch (e) {
      errorMessage.value = 'Lỗi khởi tạo: $e';
    }
  }

  Future<String?> _getCurrentStoreId() async {
    try {
      final store = await _sellerStoreService.getCurrentSellerStore();

      if (store != null) {
        return store.storeId;
      } else {
        return null;
      }
    } catch (e) {
      return null;
    }
  }

  void _updateOrderCounts() {
    pendingOrdersCount.value = orders.where((order) => order.status == 'pending').length;
    totalOrdersCount.value = orders.length;
  }

  Future<void> updateOrderStatus(String orderId, String newStatus) async {
    try {
      final order = orders.firstWhere((order) => order.orderId == orderId);
      final updatedOrder = order.copyWith(status: newStatus);

      await _orderService.updateOrder(orderId, updatedOrder);

      // Update local list
      final index = orders.indexWhere((order) => order.orderId == orderId);
      if (index != -1) {
        orders[index] = updatedOrder;
        _updateOrderCounts();
      }

    } catch (e) {
    }
  }

  List<OrderModel> getOrdersByStatus(String status) {
    return orders.where((order) => order.status == status).toList();
  }

  List<OrderModel> getPendingOrders() {
    return getOrdersByStatus('pending');
  }

  List<OrderModel> getConfirmedOrders() {
    return getOrdersByStatus('confirmed');
  }

  List<OrderModel> getShippedOrders() {
    return getOrdersByStatus('shipped');
  }

  List<OrderModel> getDeliveredOrders() {
    return getOrdersByStatus('delivered');
  }

  List<OrderModel> getCancelledOrders() {
    return getOrdersByStatus('cancelled');
  }

  // Method to refresh data (useful when switching stores)
  Future<void> refreshData() async {
    print('🔄 Refreshing data...');
    _clearData();
    _orderService.disposeListeners();
    _setupRealTimeListeners();
  }

  @override
  void onClose() {
    // Clean up listeners when controller is disposed
    _orderService.disposeListeners();
    super.onClose();
  }
}
